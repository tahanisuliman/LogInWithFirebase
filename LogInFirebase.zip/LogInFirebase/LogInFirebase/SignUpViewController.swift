//
//  SignUpViewController.swift
//  Design2
//
//  Created by islam magdy on 5/6/18.
//  Copyright © 2018 islam magdy. All rights reserved.
//

import UIKit
import Firebase
class SignUpViewController: UIViewController {

    @IBOutlet weak var ConfirmaPassword: UITextField!
    @IBOutlet weak var Password: UITextField!
    @IBOutlet weak var Email: UITextField!
    @IBOutlet weak var Name: UITextField!
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func CreateNewActount(_ sender: Any) {
        StartSignUp()
    }
    func StartSignUp() {
        if self.Name.text?.trimmingCharacters(in: .whitespaces) == "" || self.Email.text?.trimmingCharacters(in: .whitespaces) == "" || self.Password.text?.trimmingCharacters(in: .whitespaces) == "" || self.ConfirmaPassword.text?.trimmingCharacters(in: .whitespaces) == "" {
            let AlertController = UIAlertController(title: "خطأ", message: "الرجاء إدخال كافة المعلومات", preferredStyle: .alert)
            let alertAction = UIAlertAction(title: "حسناً", style: .default, handler: nil)
            AlertController.addAction(alertAction)
            present(AlertController, animated: true, completion: nil)
            return
        }
        if self.ConfirmaPassword.text == self.Password.text{
        Auth.auth().createUser(withEmail: Email.text!, password: Password.text!, completion: {[weak self] (FIRUser, Error) in
            if self == nil { return }
            if Error != nil {
                let AlertController = UIAlertController(title: "خطأ", message: "حدث خطأ ما أثناء تسجيل الحساب", preferredStyle: .alert)
                let alertAction = UIAlertAction(title: "حسناً", style: .default, handler: nil)
                AlertController.addAction(alertAction)
                self?.present(AlertController, animated: true, completion: nil)

            }
            else {
                self?.IHave(user : FIRUser!)
            }
        })
        }else{
            let AlertController = UIAlertController(title: "خطأ", message: "تأكد من الرمز السري", preferredStyle: .alert)
            let alertAction = UIAlertAction(title: "حسناً", style: .default, handler: nil)
            AlertController.addAction(alertAction)
                present(AlertController, animated: true, completion: nil)

        }
    }
    
    func IHave(user : User) {
        let NewUser = UserObject(Name: self.Name.text!, Email: self.Email.text!, ID: user.uid)
        NewUser.UploadInformations()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            let AppVC = ASCut.MKVC(SBN: "Main", VCN: "AppID")
            
            self.present(AppVC, animated: true, completion: nil)
        }
        
    }
    
    

}

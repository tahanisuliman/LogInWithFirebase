//
//  UserObject.swift
//  Design2
//
//  Created by Mohammed on 5/6/18.
//  Copyright © 2018 islam magdy. All rights reserved.
//

import Foundation
import Firebase

class UserObject {
    
    var Name : String
    var Email : String
    var ID : String
    
    init(Name : String , Email : String , ID : String ) {
        self.Name = Name
        self.Email = Email
        self.ID = ID
    }
    
    init(Dictionary : [String : AnyObject]) {
        guard let Name = Dictionary["Name"] as? String , let Email = Dictionary["Email"] as? String , let ID = Dictionary["ID"] as? String  else {
            
            self.Name = "" ; self.Email = "" ; self.ID = ""
            
            return
        }
        self.Name = Name
        self.Email = Email
        self.ID = ID
    }
    
    func GetDictionary()-> [String : AnyObject] {
        var newDictionary : [String : AnyObject] = [:]
        newDictionary["Name"] = self.Name as AnyObject
        newDictionary["Email"] = self.Email as AnyObject
        newDictionary["ID"] = self.ID as AnyObject
        return newDictionary
    }
    
    func UploadInformations() {
        Database.database().reference().child("Users").child(self.ID).setValue(GetDictionary())
    }
    
    
    
    
    
    
}

class UserApi {
    
    
    static func CurrentUser(completion : @escaping (_ User : UserObject?)->()) {
        _ = Auth.auth().addStateDidChangeListener() {(auth, user) in
            guard let UserID = user?.uid else { completion(nil) ; return }
            GetUser(ID: UserID, completion: { (User : UserObject?) in
                guard let CurrentUser = User else { completion(nil) ; return }
                completion(CurrentUser)
            })
        }
    }
    
    static func GetUser(ID : String , completion : @escaping (_ User : UserObject?)->()) {
        if let CasheUser = Cashe.UserWith(ID: ID) { completion(CasheUser) ; return }
        
        Database.database().reference().child("Users").child(ID).observeSingleEvent(of: .value) { (Snapshot : DataSnapshot) in
            guard let Userdictionary = Snapshot.value as? [String : AnyObject] else { completion(nil) ; return }
            let newUser = UserObject(Dictionary: Userdictionary)
            Cashe.Users.append(newUser)
            completion(newUser)
        }
    }
    
}

class Cashe {
    
    static var Users : [UserObject] = []
    
    static func UserWith(ID : String)->UserObject? {
        for one in Users {  if ID == one.ID { return one } }
        return nil
    }
    
}


//
//  SignInViewController.swift
//  Design2
//
//  Created by Mohammed on 5/6/18.
//  Copyright © 2018 islam magdy. All rights reserved.
//

import UIKit
import Firebase
class SignInViewController: UIViewController {

    @IBOutlet weak var Password: UITextField!
    @IBOutlet weak var Email: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func SignInAction(_ sender: Any) {
        Auth.auth().signIn(withEmail: Email.text!, password: Password.text!, completion: { [weak self] (FirUser, Error) in
            if self == nil { return }
            
            if Error != nil {
                let AlertController = UIAlertController(title: "خطأ", message: "حدث خطأ ما أثناء تسجيل الحساب", preferredStyle: .alert)
                let alertAction = UIAlertAction(title: "حسناً", style: .default, handler: nil)
                AlertController.addAction(alertAction)
                self?.present(AlertController, animated: true, completion: nil)
            } else {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5 , execute: {
                    
                    let AppVC = ASCut.MKVC(SBN: "Main", VCN: "AppID")
                    self?.present(AppVC, animated: true, completion: nil)
                })
            }
            
            
        })

    }
}

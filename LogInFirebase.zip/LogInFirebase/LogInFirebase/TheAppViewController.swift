//
//  TheAppViewController.swift
//  Design2
//
//  Created by Mohammed on 5/6/18.
//  Copyright © 2018 islam magdy. All rights reserved.
//

import UIKit
import Firebase
class TheAppViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func LogOut(_ sender: Any) {
        try? Auth.auth().signOut()

        let AuthVC = ASCut.MKVC(SBN: "Main", VCN: "AuthID")
        
        present(AuthVC, animated: true, completion: nil)
    }
    
}
